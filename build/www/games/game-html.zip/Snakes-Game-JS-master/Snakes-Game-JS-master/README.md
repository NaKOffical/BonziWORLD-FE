# Snake Game

This is a repository consisting of the code files for a Snake Game made using simple HTML,CSS and Javascipt.


