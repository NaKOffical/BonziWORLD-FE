﻿=== Multicolor Glass Cursor Set ===

By: Diskette (http://www.rw-designer.com/user/79286) doothemariotime123@yopmail.com

Download: http://www.rw-designer.com/cursor-set/multicolor-glass

Author's description:

Some multicolored Glass cursors! Have fun with them on your computer! Made with Online Cursor Editor.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.