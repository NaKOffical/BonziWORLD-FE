﻿=== 3D Silver Cursor Set ===

By: The Muffin Man (http://www.rw-designer.com/user/55973) sagan.siniard@gmail.com

Download: http://www.rw-designer.com/cursor-set/3d-silver

Author's description:

''This'' time, I actually made these. One time, '''cdl''' and '''Vlasta''' were criticizing me about stealing cursors from and using them to make me claim them as mine as I was publishing them on this website.

I included some Windows 10 Aero styled cursors. I even added some other cursors recolored to the silver color. I also included hand link selects styled to the 3D silver color style.

Enjoy!

|'''2/1/2019'''|Set created
|-
|'''2/4/2019'''|Added some hand cursors
Added some more cursors
|-
|=== 2/11/2019 ===|'''Added some more hand cursors'''
'''Stopwatch cursors were fixed to match the timing with the new hand stopwatch cursors.'''
'''Added some more cursors'''

[[icon:14486]]

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.