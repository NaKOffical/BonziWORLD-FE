﻿=== Multicolored Aero Cursor Set ===

By: Neon (http://www.rw-designer.com/user/80379)

Download: http://www.rw-designer.com/cursor-set/multicolor-aero

Author's description:

Multicolored aero cursors from Vista/7/10 made on the Online Cursor Editor. Based off of Diskette's multicolored Glass cursors.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.